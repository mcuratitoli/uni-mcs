import math

@profile
def f():
    o = math.sqrt(2013)
    return o

if __name__ == '__main__':
    f()
